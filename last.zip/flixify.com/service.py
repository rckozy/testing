import time
import xbmc
from resources import service

if __name__ == '__main__':
    service.run()