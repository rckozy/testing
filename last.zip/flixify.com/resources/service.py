import time
import datetime
import os
import xbmc
import math
import xbmcaddon

from . import const
from . import cookie_store
from . import api

__skinsdir__ = "DefaultSkin"

def get_addon():
    return xbmcaddon.Addon(id=const.ADDON_ID)


xbmc.log("FLX_LOG SERVICE resources/service.py")


def log(s):
    # xbmc.log("%s FLX_LOG SERVICE: %s" % (const.PLUGIN_ID, s))
    pass


class WatchVars:
    my_id = datetime.datetime.now()
    last_tracked_url = None
    watch_time_buffer = 0
    watch_time_buffer_total = 0
    last_watch_position = -1
    total_time = 0

    last_movie_save_cw_limit_sec = 0
    SAVE_CW_LIMIT_SEC = 2 * 60


def send_watch_time():
    log("send_watch_time...")
    if WatchVars.watch_time_buffer > 1:
        watched_delta = math.fabs(WatchVars.watch_time_buffer)
        WatchVars.watch_time_buffer -= watched_delta

        last_video_id = get_addon().getSetting('last_video_id')
        user_id = get_addon().getSetting('user_id')

        WatchVars.last_movie_save_cw_limit_sec -= watched_delta

        if user_id and last_video_id:
            params = {'pos': round(WatchVars.last_watch_position, 2), 'user_id': user_id,
                      'delta_sec': round(watched_delta, 2)}
            if WatchVars.watch_time_buffer_total > 30 and WatchVars.last_movie_save_cw_limit_sec <= 0:
                params['cw'] = 1
                WatchVars.last_movie_save_cw_limit_sec = WatchVars.SAVE_CW_LIMIT_SEC

            if WatchVars.total_time and WatchVars.last_watch_position > WatchVars.total_time * 0.92:
                params['completed'] = 1

            resp = api.post_request(get_addon(),
                api.append_params_to_url(const.API_URL + '/account/watched/seen/' + last_video_id, params))

            if resp.statusCode == 403 or resp.statusCode == 419:
                log("Reset because of no authorization responce")
                cookie_store.reset(__settings__)
                xbmc.executebuiltin("XBMC.Notification(%s, %s, %d, %s)" % (
                    "Authorization Error %s" % resp.statusCode, "Please restart and login again.", 6000, __icon__))
                xbmc.executebuiltin("XBMC.ActivateWindow(Home)")
                if xbmc.Player().isPlaying():
                    xbmc.log('Stop the Player')
                    xbmc.Player().stop()


def run():
    log("Run service...")

    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        if xbmc.Player().isPlayingVideo():
            log("playing...", )
            file_url = xbmc.Player().getPlayingFile()
            last_video_url = get_addon().getSetting('last_video_url')
            log("last_video_url: %s" % last_video_url)
            log("const.ADDON_ID + _ + file_url: %s" % (const.ADDON_ID + '_' + file_url))
            log("equal: %s" % (const.ADDON_ID + '_' + file_url == last_video_url))
            pos = xbmc.Player().getTime()
            WatchVars.total_time = xbmc.Player().getTotalTime()

            # Track only videos of my addon
            if const.ADDON_ID + '_' + file_url == last_video_url:
                # Reset if video changed
                if WatchVars.last_tracked_url != file_url:
                    WatchVars.watch_time_buffer = 0
                    WatchVars.watch_time_buffer_total = 0
                    WatchVars.last_watch_position = pos
                    WatchVars.last_tracked_url = file_url
                else:
                    pass_time = math.fabs(pos - WatchVars.last_watch_position)
                    WatchVars.last_watch_position = pos
                    # Ignore cases with > 3 sec (step of checkin is 1 sec)
                    if pass_time > 3:
                        WatchVars.watch_time_buffer = 0
                        WatchVars.last_watch_position = pos
                    else:
                        WatchVars.watch_time_buffer += pass_time
                        WatchVars.watch_time_buffer_total += pass_time

                log(
                    "IS_PLAYING: pos=%s WatchVars.watch_time_buffer=%s WatchVars.watch_time_buffer_total=%s WatchVars.last_watch_position=%s" % (
                    pos, WatchVars.watch_time_buffer, WatchVars.watch_time_buffer_total, WatchVars.last_watch_position))

            if WatchVars.watch_time_buffer > 15:
                send_watch_time()

        elif WatchVars.watch_time_buffer > 1:
            send_watch_time()

        if monitor.waitForAbort(1):
            # Abort was requested while waiting. We should exit
            # log("Abort was requested while waiting. We should exit %s" % my_id)
            break
