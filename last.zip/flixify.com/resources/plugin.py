import os
import traceback
import sys
import xbmc, xbmcaddon

__skinsdir__ = "DefaultSkin"

__id__ = 'flixify.com'
__addon__ = xbmcaddon.Addon(id=__id__)
__settings__ = xbmcaddon.Addon(id=__id__)

# _ADDON_PATH = xbmc.translatePath(__addon__.getAddonInfo('path'))
# if (sys.platform == 'win32') or (sys.platform == 'win64'):
#     _ADDON_PATH = _ADDON_PATH.decode('utf-8')

# sys.path.append(os.path.join(_ADDON_PATH, 'resources', 'lib'))
# sys.path.append(os.path.join(_ADDON_PATH, 'resources', 'skins'))
# sys.path.append(os.path.join(_ADDON_PATH, 'resources', 'skins', __skinsdir__))

# from resource.lib import cookie_store as cookie_store
from . import const
from . import cookie_store
from . import api
from . import addon_main_worker

# from resource.lib api


def log(str):
    xbmc.log("%s FLX_LOG: %s" % (const.PLUGIN_ID, str))
    const.GLOBAL_LAST_LOGS.append(str)
    const.GLOBAL_LAST_LOGS = const.GLOBAL_LAST_LOGS[-5:]


def run():
    log("RUN()")
    log("sys.version = " + str(sys.version))

    try:
        if not cookie_store.has_auth(__settings__):
            cookie_store.reset(__settings__, 'not has_auth')
        else:
            try:
                reset_auth = int(__settings__.getSetting('reset_auth'))
            except:
                reset_auth = 0

            if reset_auth == 1:
                cookie_store.reset(__settings__, 'reset_auth = 1')

        addon_main_worker.init()

    except Exception as e:
        # Get current system exception
        ex_type, ex_value, ex_traceback = sys.exc_info()

        # Extract unformatter stack traces as tuples
        trace_back = traceback.extract_tb(ex_traceback)

        # Format stacktrace
        stack_trace = list()

        for trace in trace_back:
            # stack_trace.append("File : %s , Line : %d, Func.Name : %s, Message : %s" % (trace[0], trace[1], trace[2], trace[3]))
            stack_trace.append("File \"%s\", line %d, in %s:\n\t%s\n" % (trace[0], trace[1], trace[2], trace[3]))

        # log("Exception type : %s " % ex_type.__name__)
        # log("Exception message : %s" % ex_value)
        # log("Stack trace : %s" % stack_trace)

        api.trk_exception(__settings__, ex_type.__name__, ex_value, stack_trace)

        raise
