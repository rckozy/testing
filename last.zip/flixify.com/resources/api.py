import sys
import traceback
import xbmc, xbmcaddon
import json
import time
from . import cookie_store
from . import const
try:
    from http.cookiejar import CookieJar
except ImportError:
    from cookielib import CookieJar

try:
    # For Python 3.0 and later
    from urllib.request import HTTPRedirectHandler, build_opener, HTTPCookieProcessor, Request
    from urllib.error import URLError
    from urllib.parse import urlencode
except ImportError:
    # Fall back to Python 2's urllib2
    from urllib2 import HTTPRedirectHandler, build_opener, HTTPCookieProcessor, Request, URLError
    from urllib import urlencode

__addon__ = xbmcaddon.Addon(id=const.ADDON_ID)

def log(str):
    xbmc.log("FLX_LOG Api: %s" % str)


# noinspection PyUnresolvedReferences
try: # check whether python knows about 'basestring'
    basestring
except NameError: # no, it doesn't (it's Python3); use 'str' instead
    basestring=str


def is_string(obj):
    return isinstance(obj, basestring)


class SmartRedirectHandler(HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        newurl = None
        for key in ('location', 'uri'):
            if key in headers:
                newurl = headers[key]
                break
        log("SmartRedirectHandler.http_error_302 %s for %s to %s" % (str(code), req.get_full_url(), newurl))
        if newurl and ('/login' in newurl or '/logout' in newurl):  # pragma: no cover
            raise Exception('Authorization Lost by ' + str(code) + ' to ' + newurl)
            return

        result = HTTPRedirectHandler.http_error_302(self, req, fp, code, msg, headers)
        result.status = code
        return result


class ApiResp:
    def __init__(self, status_code, data=None, error=None):
        self.statusCode = status_code
        self.data = data
        self.error = error


def pretty_print_POST(self, req):
    log('{}\n{}\n{}\n\n{}'.format(
        '-----------START-----------',
        req.method + ' ' + req.url,
        '\n'.join('{}: {}'.format(k, v) for k, v in req.headers.items()),
        req.body,
    ))


def append_params_to_url(url, params):
    if params:
        url = url + ('&' if '?' in url else '?') + urlencode(params)
    return url


def trk(settings, event, params=None):
    if params is None:
        params = {}

    params['e'] = 'kodi_' + event
    params['_v'] = settings.getAddonInfo('version')

    get_request(settings, const.API_URL + '/trk', params)

def trk_exception(settings, etype, emessage, estack_list):
    params = {}

    params['name'] = 'Kodi Exception'
    params['_v'] = '9999'
    params['_kv'] = settings.getAddonInfo('version')

    params['_ts'] = str(time.time())
    params['type'] = str(etype)
    params['message'] = str(emessage)
    params['stack'] = str(estack_list)
    params['last_logs'] = str(const.GLOBAL_LAST_LOGS)

    get_request(settings, const.API_URL + '/api/error', params)

def trk_resp_error(settings, url, status, message):
    params = {}

    params['name'] = 'Kodi Resp Error'
    params['_v'] = '9999'
    params['_kv'] = settings.getAddonInfo('version')

    params['status'] = str(status)
    params['url'] = str(url)
    params['message'] = str(message)
    params['last_logs'] = str(const.GLOBAL_LAST_LOGS)

    get_request(settings, const.API_URL + '/api/error', params)


def get_request(settings, url, params=None):
    url = append_params_to_url(url, params)
    return __request(settings, url)


def post_request(settings, url, params=None):

    if params is not None:
        params = urlencode(params)
    else:
        params = urlencode({"_": str(time.time())})
    return __request(settings, url, params)


def __request(settings, url, post_data=None, timeout=600):
    url = url + ('&' if '?' in url else '?') + "_=" + str(time.time())
    method = 'GET'
    if post_data:
        method = 'POST'
    log("REQUEST %s URL=%s" % (method, url))
    if post_data:
        log("REQUEST POST DATA: %s" % post_data)

    try:
        cj = cookie_store.restore_cookies(settings, CookieJar())

        opener = build_opener(SmartRedirectHandler, HTTPCookieProcessor(cj))
        headers = {'User-Agent': 'PP-base Kodi plugin %s' % settings.getAddonInfo('version'), 'Accept': 'application/json'}

        if isinstance(post_data, str):
            post_data = post_data.encode("utf-8")

        req = Request(url=url, data=post_data, headers=headers)

        # pretty_print_POST(req.prepare())
        log("REQ HEADERS: %s" % req.header_items())
        # log("REQ COOKIES: %s" % cj)
        resp = opener.open(req, timeout=timeout)
        log("RESP INFO: %s" % resp.info())

        resp_code = resp.code
        resp_data = None
        try:
            resp_data = resp.read()
            if resp:
                resp = json.loads(resp_data)
            else:
                resp = resp_data
        except:
            resp = {}
            pass


        if resp_code != 200:
            log("RESP FAIL %s: %s" % (str(resp_code), ((str(resp_data[:256]) + '..') if len(resp_data) > 75 else str(resp_data))))
            # log("RESP FAIL INFO: %s" % resp.info())
            return ApiResp(resp_code, resp, 'Unknown error')


        log("RESP %s: %s" % (str(resp_code), ((str(resp_data[:256]) + '..') if len(resp_data) > 75 else str(resp_data))))

        cookie_store.store_cookies(settings, cj)


        return ApiResp(resp_code, resp)

    except URLError as e:
        try:
            body = ''.join(e.readlines())
            if body:
                result = json.loads(body)
                if result['message']:
                    return ApiResp(e.code, None, str(result['message']))
        except:
            pass

        return ApiResp(-1, None, 'Unknown error')

    except Exception as e:
        log("RESP Exception: %s" % e)
        # Get current system exception
        ex_type, ex_value, ex_traceback = sys.exc_info()

        # Extract unformatter stack traces as tuples
        trace_back = traceback.extract_tb(ex_traceback)

        # Format stacktrace
        stack_trace = list()

        for trace in trace_back:
            stack_trace.append("File : %s , Line : %d, Func.Name : %s, Message : %s" % (trace[0], trace[1], trace[2], trace[3]))

        log("Exception type : %s " % ex_type.__name__)
        log("Exception message : %s" % ex_value)
        log("Stack trace : %s" % stack_trace)

        return ApiResp(-1, None, e)

    xbmc.executebuiltin("XBMC.Notification(%s,%s)" % ("Internet problems", "Connection timed out!"))
