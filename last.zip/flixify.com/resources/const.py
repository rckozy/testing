
ADDON_ID = 'flixify.com'
CHECK_AUTH_API_URL = "https://flx-srv.com/kodi/api/api/logged_in"
PIN_API_URL = "https://flx-srv.com/kodi/api/pin/generate"
PIN_CHECK_API_URL = "https://flx-srv.com/kodi/api/pin/login"

API_URL = "https://flx-srv.com/kodi/api"

PLUGIN_ID = "plugin://%s" % ADDON_ID

GLOBAL_LAST_LOGS = []