import os, xbmc, xbmcaddon

def run():
    xbmc.log("%s FLX_LOG: %s" % (const.PLUGIN_ID, str))